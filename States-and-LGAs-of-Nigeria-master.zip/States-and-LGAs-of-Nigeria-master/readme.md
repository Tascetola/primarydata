# List & SQL of Nigerian States and LGAs

Full list of all 36 states of Nigeria and their Local Government Areas (Councils)

## Contents

List of states
List of LGAs by State
SQL for states
SQL for LGAs

## Contributing

Please feel free to fork, copy, replicate, distrubute...anything really. PRs are welcome in case this list needs updating.

Cheers!